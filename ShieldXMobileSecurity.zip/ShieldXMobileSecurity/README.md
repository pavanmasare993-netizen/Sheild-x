# ShieldX Mobile Security — Android Project Scaffold

Kotlin + Jetpack Compose Android app implementing your full feature list.
This is a **working scaffold**: navigation, auth, and several modules have
real logic; the rest are stubbed with clear TODOs and reusable patterns to
finish them fastest.

## How to open it
1. Install **Android Studio** (Koala or newer).
2. `File > Open` → select the `ShieldXMobileSecurity` folder.
3. Let Gradle sync (it will download dependencies — needs internet).
4. You need a **Firebase project**: go to the Firebase console, create a
   project named ShieldX, add an Android app with package name
   `com.shieldx.security`, download `google-services.json`, and drop it in
   `app/`. Without this file the build will fail (Firebase Auth/Firestore
   won't initialize).
5. Run on a physical device or emulator with **API 26+**.

## What's fully implemented
| Module | Status |
|---|---|
| Login / Signup | Real — Firebase Auth email/password |
| Dashboard | Real — grid nav to all 15 modules + security score card |
| Device Security Check | Real — screen lock, root, dev options, unknown sources |
| Battery Health Monitor | Real — live BatteryManager readings |
| RAM Monitor | Real — live ActivityManager.MemoryInfo |
| Permission Manager | Real — scans installed apps for dangerous permissions |
| App Lock | Real — AccessibilityService + BiometricPrompt unlock overlay |
| Anti-Theft | Real — DevicePolicyManager Lock Now; Find/Alarm/Wipe stubbed |
| VPN | Real service skeleton (local TUN) — needs WireGuard/OpenVPN for real tunneling |
| Wi-Fi Security Check | Partial — reads SSID; full WPA2/WPA3 detection is a TODO |

## What's stubbed (see TODO comments in each file)
Privacy Scanner, Safe Browsing, Phishing Detection, Junk Cleaner, Storage
Analyzer, Security Alerts, Cloud Backup, Settings. Each stub screen states
exactly which API/library to wire up next.

## Important Android platform constraints
- **Junk Cleaner**: Android has not allowed apps to silently clear other
  apps' cache since API 26. ShieldX can only clear its own cache directly;
  for anything else it must deep-link the user to system Settings.
- **App Lock**: requires the user to manually enable the Accessibility
  Service (Play Store review is strict about Accessibility usage — be ready
  to justify it in your Play Console submission).
- **Anti-Theft Wipe**: requires Device Admin activation; on modern Android,
  a full "Find My Device"-style remote wipe from a third-party app also
  typically requires the device to be enrolled as a Device Owner (MDM-style),
  which isn't possible for a normal consumer install. `dpm.wipeData()` still
  works for Device Admin apps but Google has tightened this over time —
  test carefully on your target API levels.
- **VPN**: `ShieldXVpnService` is a bare TUN skeleton. To actually encrypt
  traffic to a remote server, integrate `com.wireguard.android:tunnel` or
  an OpenVPN client library — building packet tunneling from scratch is a
  multi-week project on its own.
- **Play Store policy**: QUERY_ALL_PACKAGES, PACKAGE_USAGE_STATS,
  MANAGE_EXTERNAL_STORAGE, and Accessibility Service usage all require a
  declared, justified use-case in Play Console and are reviewed manually.
  Budget time for this before submission.

## Suggested build order (finish the stubs)
1. Privacy Scanner (reuses Permission Manager's scan)
2. Storage Analyzer (StorageStatsManager)
3. Junk Cleaner (own-app cache + Settings deep link)
4. Alerts (Room table + NotificationCompat, feed events from other modules into it)
5. Safe Browsing (Google Safe Browsing API)
6. Phishing Detection (builds on Safe Browsing's URL check)
7. Settings (module toggles + sign-out)
8. Cloud Backup (Firestore, optional)
9. Wire real WireGuard/OpenVPN into the VPN module
10. Finish Anti-Theft Find/Alarm (FusedLocationProvider + MediaPlayer)

## Architecture
- **UI**: Jetpack Compose, one package per feature under `ui/`
- **Navigation**: single `NavHost` in `navigation/ShieldXNavHost.kt`, routes in `Routes.kt`
- **Auth**: Firebase Auth via `AuthViewModel`
- **Local persistence**: SharedPreferences for simple flags (see
  `LockedAppsRepository`); Room is included as a dependency for when Alerts
  history / scan logs need real querying
- **Background system components**: `AppLockAccessibilityService`,
  `DeviceAdminReceiver`, `ShieldXVpnService` — all declared in
  `AndroidManifest.xml`

## Next steps
Open the project in Android Studio, add `google-services.json`, hit Run,
and you'll land on the Login screen → Dashboard → all 16 module cards are
tappable today (some show real data, some show their TODO scaffold).
