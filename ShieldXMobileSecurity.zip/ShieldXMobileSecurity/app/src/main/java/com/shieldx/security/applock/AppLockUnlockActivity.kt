package com.shieldx.security.applock

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.shieldx.security.ui.theme.ShieldXTheme

/**
 * Full-screen overlay shown by AppLockAccessibilityService when a locked
 * app is opened. Uses BiometricPrompt (falls back to device PIN/pattern
 * automatically via setDeviceCredentialAllowed / setAllowedAuthenticators).
 */
class AppLockUnlockActivity : ComponentActivity() {
    companion object {
        const val EXTRA_TARGET_PACKAGE = "target_package"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val targetPackage = intent.getStringExtra(EXTRA_TARGET_PACKAGE)

        setContent {
            ShieldXTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                        Text("Unlocking ${targetPackage ?: "app"}…")
                    }
                }
                LaunchedBiometricPrompt(onSuccess = { finish() }, onFail = { finish() })
            }
        }
    }
}

@Composable
private fun LaunchedBiometricPrompt(onSuccess: () -> Unit, onFail: () -> Unit) {
    val context = LocalContext.current
    val activity = context as ComponentActivity

    val executor = ContextCompat.getMainExecutor(context)
    val promptInfo = BiometricPrompt.PromptInfo.Builder()
        .setTitle("ShieldX App Lock")
        .setSubtitle("Authenticate to open this app")
        .setAllowedAuthenticators(
            BiometricManager.Authenticators.BIOMETRIC_WEAK or
                    BiometricManager.Authenticators.DEVICE_CREDENTIAL
        )
        .build()

    val prompt = BiometricPrompt(activity, executor, object : BiometricPrompt.AuthenticationCallback() {
        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
            onSuccess()
        }
        override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
            onFail()
        }
        override fun onAuthenticationFailed() {
            // let the user retry; BiometricPrompt handles retry UI itself
        }
    })

    androidx.compose.runtime.LaunchedEffect(Unit) {
        prompt.authenticate(promptInfo)
    }
}
