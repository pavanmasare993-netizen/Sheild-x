package com.shieldx.security.ui.alerts

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import com.shieldx.security.ui.common.PlaceholderScreen

/**
 * TODO: Aggregate a feed of events from all modules (device check failures,
 * malware found, VPN dropped, Wi-Fi risk, junk cleaned) into a Room table,
 * surfaced here and pushed via NotificationCompat + Firebase Cloud Messaging.
 */
@Composable
fun AlertsScreen(navController: NavHostController) {
    PlaceholderScreen(
        title = "Security Alerts",
        navController = navController,
        note = "Central feed of events from every module, persisted in Room and pushed via notifications."
    )
}
