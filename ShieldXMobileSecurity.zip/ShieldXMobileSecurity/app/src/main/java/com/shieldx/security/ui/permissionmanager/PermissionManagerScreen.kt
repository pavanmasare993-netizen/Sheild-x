package com.shieldx.security.ui.permissionmanager

import android.content.pm.PackageManager
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController

private val DANGEROUS_PERMISSIONS = setOf(
    "android.permission.CAMERA", "android.permission.RECORD_AUDIO",
    "android.permission.ACCESS_FINE_LOCATION", "android.permission.READ_CONTACTS",
    "android.permission.READ_SMS", "android.permission.READ_CALL_LOG",
    "android.permission.READ_EXTERNAL_STORAGE", "android.permission.BODY_SENSORS"
)

private data class AppPermissionInfo(val label: String, val packageName: String, val granted: List<String>)

private fun scanAppPermissions(pm: PackageManager): List<AppPermissionInfo> {
    val packages = pm.getInstalledPackages(PackageManager.GET_PERMISSIONS)
    return packages.mapNotNull { pkg ->
        val granted = pkg.requestedPermissions
            ?.filterIndexed { i, perm ->
                perm in DANGEROUS_PERMISSIONS &&
                        (pkg.requestedPermissionsFlags?.getOrNull(i)?.and(PackageInfoCompatFlag) != 0)
            } ?: emptyList()
        if (granted.isEmpty()) null
        else {
            val label = pm.getApplicationLabel(pkg.applicationInfo!!).toString()
            AppPermissionInfo(label, pkg.packageName, granted)
        }
    }.sortedByDescending { it.granted.size }
}

// PackageInfo.REQUESTED_PERMISSION_GRANTED constant, aliased for readability
private const val PackageInfoCompatFlag =
    android.content.pm.PackageInfo.REQUESTED_PERMISSION_GRANTED

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PermissionManagerScreen(navController: NavHostController) {
    val context = LocalContext.current
    val results = remember { scanAppPermissions(context.packageManager) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Permission Manager") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(modifier = Modifier.padding(padding)) {
            items(results) { app ->
                Column(modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp)) {
                    Text(app.label, style = MaterialTheme.typography.bodyLarge)
                    Text(
                        app.granted.joinToString { it.substringAfterLast('.') },
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                HorizontalDivider()
            }
        }
    }
}
