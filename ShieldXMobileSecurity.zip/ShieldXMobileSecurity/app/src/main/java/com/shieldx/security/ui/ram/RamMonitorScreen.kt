package com.shieldx.security.ui.ram

import android.app.ActivityManager
import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import kotlin.math.roundToInt

private data class RamInfo(
    val totalMb: Long,
    val availMb: Long,
    val usedMb: Long,
    val usedPercent: Int,
    val lowMemory: Boolean,
    val topApps: List<Pair<String, Long>>
)

private fun readRam(context: Context): RamInfo {
    val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val memInfo = ActivityManager.MemoryInfo()
    am.getMemoryInfo(memInfo)

    val totalMb = memInfo.totalMem / (1024 * 1024)
    val availMb = memInfo.availMem / (1024 * 1024)
    val usedMb = totalMb - availMb
    val usedPercent = if (totalMb > 0) ((usedMb.toDouble() / totalMb) * 100).roundToInt() else 0

    // Per-app memory requires PACKAGE_USAGE_STATS + iterating running processes;
    // exposed here as a stub list for the UI. Wire up UsageStatsManager for real data.
    val topApps = emptyList<Pair<String, Long>>()

    return RamInfo(totalMb, availMb, usedMb, usedPercent, memInfo.lowMemory, topApps)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RamMonitorScreen(navController: NavHostController) {
    val context = LocalContext.current
    var info by remember { mutableStateOf(readRam(context)) }

    LaunchedEffect(Unit) {
        while (true) {
            info = readRam(context)
            kotlinx.coroutines.delay(3000)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("RAM Monitor") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp)
        ) {
            LinearProgressIndicator(
                progress = { info.usedPercent / 100f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(10.dp)
            )
            Spacer(Modifier.height(8.dp))
            Text("${info.usedPercent}% used  •  ${info.usedMb} MB / ${info.totalMb} MB")

            Spacer(Modifier.height(20.dp))
            Text("Available", style = MaterialTheme.typography.labelMedium)
            Text("${info.availMb} MB", style = MaterialTheme.typography.headlineSmall)

            if (info.lowMemory) {
                Spacer(Modifier.height(16.dp))
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)) {
                    Text("⚠ Device is running low on memory", modifier = Modifier.padding(16.dp))
                }
            }

            Spacer(Modifier.height(24.dp))
            Text(
                "Note: per-app RAM usage requires the Usage Access permission " +
                        "(UsageStatsManager). Grant it in Settings to enable the top-apps list.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
