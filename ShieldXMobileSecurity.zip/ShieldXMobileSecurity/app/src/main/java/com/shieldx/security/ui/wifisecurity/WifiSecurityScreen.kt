package com.shieldx.security.ui.wifisecurity

import android.content.Context
import android.net.wifi.WifiManager
import android.os.Build
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.shieldx.security.ui.theme.ShieldGreen
import com.shieldx.security.ui.theme.ShieldRed

private data class WifiStatus(val ssid: String, val secure: Boolean, val note: String)

private fun readWifiStatus(context: Context): WifiStatus {
    val wifiManager = context.applicationContext
        .getSystemService(Context.WIFI_SERVICE) as WifiManager
    val info = wifiManager.connectionInfo
    val ssid = info?.ssid?.replace("\"", "") ?: "Not connected"

    // Real security-type detection (WPA3 vs WPA2 vs open) requires
    // NetworkCapabilities / ScanResult parsing on API 30+, plus
    // ACCESS_FINE_LOCATION granted at runtime. This gives a baseline read.
    val secure = ssid != "Not connected" && ssid != "<unknown ssid>"
    val note = when {
        ssid == "Not connected" -> "Connect to Wi-Fi to scan its security"
        !secure -> "Could not verify network name — grant Location permission"
        else -> "Connected. Full WPA2/WPA3 + captive-portal checks require " +
                "runtime location permission and ScanResult parsing (see TODO in code)."
    }
    return WifiStatus(ssid, secure, note)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WifiSecurityScreen(navController: NavHostController) {
    val context = LocalContext.current
    val status = remember { readWifiStatus(context) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Wi-Fi Security Check") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp)
        ) {
            Text("Network: ${status.ssid}", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(12.dp))
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (status.secure)
                        ShieldGreen.copy(alpha = 0.12f) else ShieldRed.copy(alpha = 0.12f)
                )
            ) {
                Text(status.note, modifier = Modifier.padding(16.dp))
            }
            Spacer(Modifier.height(20.dp))
            Text(
                "TODO for full implementation:\n" +
                        "• Request ACCESS_FINE_LOCATION at runtime (required by Android to read SSID/scan results)\n" +
                        "• Parse WifiInfo.getCurrentSecurityType() (API 33+) or ScanResult.capabilities for WPA2/WPA3/open\n" +
                        "• Flag open networks and known-weak WEP/WPA-TKIP\n" +
                        "• Optionally detect captive portals / ARP spoofing on the LAN",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
