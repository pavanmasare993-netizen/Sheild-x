package com.shieldx.security.ui.storageanalyzer

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import com.shieldx.security.ui.common.PlaceholderScreen

/**
 * TODO: Use StorageManager + StorageStatsManager (API 26+) to break down
 * used/free space, and per-app storage stats if permission is granted.
 * Render as a pie/bar chart.
 */
@Composable
fun StorageAnalyzerScreen(navController: NavHostController) {
    PlaceholderScreen(
        title = "Storage Analyzer",
        navController = navController,
        note = "Reads StorageStatsManager for used/free breakdown by category (apps, media, cache, other)."
    )
}
