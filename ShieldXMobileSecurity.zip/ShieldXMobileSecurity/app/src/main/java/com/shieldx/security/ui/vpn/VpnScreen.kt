package com.shieldx.security.ui.vpn

import android.content.Intent
import android.net.VpnService
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.shieldx.security.vpn.ShieldXVpnService

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VpnScreen(navController: NavHostController) {
    val context = LocalContext.current
    var connected by remember { mutableStateOf(false) }

    val vpnPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            context.startService(Intent(context, ShieldXVpnService::class.java))
            connected = true
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("VPN") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(if (connected) "Protected" else "Not Connected", style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(16.dp))
            Button(onClick = {
                if (connected) {
                    context.stopService(Intent(context, ShieldXVpnService::class.java))
                    connected = false
                } else {
                    val intent = VpnService.prepare(context)
                    if (intent != null) {
                        vpnPermissionLauncher.launch(intent)
                    } else {
                        context.startService(Intent(context, ShieldXVpnService::class.java))
                        connected = true
                    }
                }
            }) {
                Text(if (connected) "Disconnect" else "Connect")
            }
            Spacer(Modifier.height(20.dp))
            Text(
                "Current implementation is a local packet-filtering TUN (see ShieldXVpnService). " +
                        "For encrypted tunneling to a remote VPN endpoint, integrate WireGuard-android or OpenVPN.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
