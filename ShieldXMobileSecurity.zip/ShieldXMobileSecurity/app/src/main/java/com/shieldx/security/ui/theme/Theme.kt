package com.shieldx.security.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// ShieldX palette: deep navy + shield-blue + alert red/green for status
val ShieldNavy = Color(0xFF0B1B33)
val ShieldBlue = Color(0xFF2563EB)
val ShieldBlueLight = Color(0xFF60A5FA)
val ShieldGreen = Color(0xFF16A34A)
val ShieldRed = Color(0xFFDC2626)
val ShieldAmber = Color(0xFFF59E0B)
val ShieldSurfaceDark = Color(0xFF111827)

private val DarkColors = darkColorScheme(
    primary = ShieldBlue,
    secondary = ShieldBlueLight,
    background = ShieldNavy,
    surface = ShieldSurfaceDark,
    error = ShieldRed
)

private val LightColors = lightColorScheme(
    primary = ShieldBlue,
    secondary = ShieldBlueLight,
    background = Color(0xFFF5F7FA),
    surface = Color.White,
    error = ShieldRed
)

@Composable
fun ShieldXTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colors,
        content = content
    )
}
