package com.shieldx.security

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.shieldx.security.navigation.ShieldXNavHost
import com.shieldx.security.ui.theme.ShieldXTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ShieldXTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    ShieldXNavHost()
                }
            }
        }
    }
}
