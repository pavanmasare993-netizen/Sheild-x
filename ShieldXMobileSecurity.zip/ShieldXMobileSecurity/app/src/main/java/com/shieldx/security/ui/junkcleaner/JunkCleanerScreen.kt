package com.shieldx.security.ui.junkcleaner

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import com.shieldx.security.ui.common.PlaceholderScreen

/**
 * TODO: On API 30+, MANAGE_EXTERNAL_STORAGE is heavily restricted by Play
 * policy for non-file-manager apps. Realistic implementation: use
 * StorageStatsManager to clear ShieldX's own cache, and guide the user to
 * Settings > Storage for system-wide junk (Android doesn't allow third-party
 * apps to silently delete other apps' cache since API 26).
 */
@Composable
fun JunkCleanerScreen(navController: NavHostController) {
    PlaceholderScreen(
        title = "Junk File Cleaner",
        navController = navController,
        note = "Clears ShieldX's own cache directly; for system-wide junk, deep-links to Settings > Storage (Android restricts silent cross-app cache clearing since API 26)."
    )
}
