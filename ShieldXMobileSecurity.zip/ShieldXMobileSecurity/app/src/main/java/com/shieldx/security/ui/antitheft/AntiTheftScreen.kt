package com.shieldx.security.ui.antitheft

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.shieldx.security.antitheft.DeviceAdminReceiver

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AntiTheftScreen(navController: NavHostController) {
    val context = LocalContext.current
    val dpm = context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
    val adminComponent = ComponentName(context, DeviceAdminReceiver::class.java)
    val isAdminActive = dpm.isAdminActive(adminComponent)

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Anti-Theft") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp)
        ) {
            if (!isAdminActive) {
                Text(
                    "Device admin permission is required for remote Lock and Wipe.",
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(12.dp))
                Button(onClick = {
                    val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                        putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent)
                        putExtra(
                            DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                            "Enables remote Lock and Wipe if your device is lost or stolen."
                        )
                    }
                    context.startActivity(intent)
                }) {
                    Text("Enable Device Admin")
                }
            } else {
                Text("Device admin: Active ✓", style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(20.dp))

                Button(
                    onClick = { /* TODO: fetch last known location via FusedLocationProvider, show on map */ },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Find My Device") }

                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = { dpm.lockNow() },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Lock Now") }

                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = { /* TODO: trigger MediaPlayer loop at max volume, ignoring silent mode */ },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Sound Alarm") }

                Spacer(Modifier.height(24.dp))
                Button(
                    onClick = { /* TODO: confirm with a strong dialog before wiping */ },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error),
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Wipe Device") }
            }
        }
    }
}
