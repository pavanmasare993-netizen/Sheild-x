package com.shieldx.security

import android.app.Application
import com.google.firebase.FirebaseApp

class ShieldXApp : Application() {
    override fun onCreate() {
        super.onCreate()
        FirebaseApp.initializeApp(this)
    }
}
