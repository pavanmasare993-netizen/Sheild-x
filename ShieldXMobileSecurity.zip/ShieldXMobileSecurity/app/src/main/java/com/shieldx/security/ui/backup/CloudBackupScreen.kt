package com.shieldx.security.ui.backup

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import com.shieldx.security.ui.common.PlaceholderScreen

/**
 * TODO: Optional module — back up ShieldX settings (locked-app list, alert
 * history, scan results) to Firebase Firestore/Storage keyed by the
 * authenticated user's UID from AuthViewModel.currentUserId().
 */
@Composable
fun CloudBackupScreen(navController: NavHostController) {
    PlaceholderScreen(
        title = "Cloud Backup",
        navController = navController,
        note = "Backs up ShieldX settings and scan history to Firestore, scoped to the signed-in user."
    )
}
