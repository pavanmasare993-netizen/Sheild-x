package com.shieldx.security.ui.devicesecurity

import android.app.KeyguardManager
import android.content.Context
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.shieldx.security.ui.theme.ShieldGreen
import com.shieldx.security.ui.theme.ShieldRed
import java.io.File

private data class SecurityCheckItem(val title: String, val passed: Boolean, val detail: String)

private fun isDeviceRooted(): Boolean {
    val paths = arrayOf(
        "/system/app/Superuser.apk", "/sbin/su", "/system/bin/su",
        "/system/xbin/su", "/data/local/xbin/su", "/data/local/bin/su",
        "/system/sd/xbin/su", "/system/bin/failsafe/su", "/data/local/su"
    )
    return paths.any { File(it).exists() }
}

private fun runChecks(context: Context): List<SecurityCheckItem> {
    val keyguard = context.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
    val hasLockScreen = keyguard.isDeviceSecure

    val devOptionsEnabled = Settings.Secure.getInt(
        context.contentResolver, Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0
    ) == 1

    val unknownSourcesEnabled = try {
        Settings.Secure.getInt(context.contentResolver, "install_non_market_apps", 0) == 1
    } catch (e: Exception) {
        false
    }

    val rooted = isDeviceRooted()

    return listOf(
        SecurityCheckItem(
            "Screen Lock", hasLockScreen,
            if (hasLockScreen) "PIN/pattern/biometric is set" else "No lock screen configured"
        ),
        SecurityCheckItem(
            "Root Status", !rooted,
            if (rooted) "Root access indicators found" else "No root indicators detected"
        ),
        SecurityCheckItem(
            "Developer Options", !devOptionsEnabled,
            if (devOptionsEnabled) "Developer options are ON" else "Developer options are off"
        ),
        SecurityCheckItem(
            "Unknown Sources", !unknownSourcesEnabled,
            if (unknownSourcesEnabled) "Installing from unknown sources is allowed" else "Unknown sources blocked"
        )
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DeviceSecurityCheckScreen(navController: NavHostController) {
    val context = LocalContext.current
    val checks = remember { runChecks(context) }
    val passedCount = checks.count { it.passed }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Device Security Check") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp)
        ) {
            Text(
                "$passedCount / ${checks.size} checks passed",
                style = MaterialTheme.typography.titleLarge
            )
            Spacer(Modifier.height(16.dp))
            checks.forEach { item ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 10.dp)
                ) {
                    Icon(
                        if (item.passed) Icons.Filled.CheckCircle else Icons.Filled.Warning,
                        contentDescription = null,
                        tint = if (item.passed) ShieldGreen else ShieldRed
                    )
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text(item.title, style = MaterialTheme.typography.bodyLarge)
                        Text(item.detail, style = MaterialTheme.typography.bodySmall)
                    }
                }
                HorizontalDivider()
            }
        }
    }
}
