package com.shieldx.security.navigation

sealed class Routes(val route: String) {
    object Login : Routes("login")
    object Signup : Routes("signup")
    object Dashboard : Routes("dashboard")
    object AppLock : Routes("app_lock")
    object PrivacyScanner : Routes("privacy_scanner")
    object PermissionManager : Routes("permission_manager")
    object DeviceSecurityCheck : Routes("device_security_check")
    object WifiSecurityCheck : Routes("wifi_security_check")
    object SafeBrowsing : Routes("safe_browsing")
    object PhishingDetection : Routes("phishing_detection")
    object AntiTheft : Routes("anti_theft")
    object JunkCleaner : Routes("junk_cleaner")
    object StorageAnalyzer : Routes("storage_analyzer")
    object BatteryHealth : Routes("battery_health")
    object RamMonitor : Routes("ram_monitor")
    object Vpn : Routes("vpn")
    object Alerts : Routes("alerts")
    object CloudBackup : Routes("cloud_backup")
    object Settings : Routes("settings")
}
