package com.shieldx.security.applock

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import com.shieldx.security.data.repository.LockedAppsRepository

/**
 * Watches TYPE_WINDOW_STATE_CHANGED events to detect when a locked app
 * comes to the foreground, then launches the PIN/biometric unlock screen
 * on top of it. Requires the user to enable this service under
 * Settings > Accessibility > ShieldX.
 */
class AppLockAccessibilityService : AccessibilityService() {

    private var lastUnlockedPackage: String? = null

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val packageName = event?.packageName?.toString() ?: return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        if (packageName == this.packageName) return // ignore ShieldX itself
        if (packageName == lastUnlockedPackage) return

        val lockedApps = LockedAppsRepository.getLockedPackages(this)
        if (packageName in lockedApps) {
            val intent = Intent(this, AppLockUnlockActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
                putExtra(AppLockUnlockActivity.EXTRA_TARGET_PACKAGE, packageName)
            }
            startActivity(intent)
        } else {
            lastUnlockedPackage = packageName
        }
    }

    override fun onInterrupt() {}
}
