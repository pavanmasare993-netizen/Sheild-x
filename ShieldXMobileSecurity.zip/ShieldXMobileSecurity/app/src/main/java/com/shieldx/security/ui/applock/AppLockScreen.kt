package com.shieldx.security.ui.applock

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.shieldx.security.data.repository.LockedAppsRepository

private fun getUserInstalledApps(pm: PackageManager): List<ApplicationInfo> {
    return pm.getInstalledApplications(PackageManager.GET_META_DATA)
        .filter { (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 }
        .sortedBy { pm.getApplicationLabel(it).toString().lowercase() }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppLockScreen(navController: NavHostController) {
    val context = LocalContext.current
    val pm = context.packageManager
    val apps = remember { getUserInstalledApps(pm) }
    var lockedPackages by remember { mutableStateOf(LockedAppsRepository.getLockedPackages(context)) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("App Lock") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding)) {
            Card(modifier = Modifier.padding(16.dp)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "App Lock needs Accessibility Service access to detect " +
                                "when a locked app is opened.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = {
                        context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    }) {
                        Text("Open Accessibility Settings")
                    }
                }
            }

            LazyColumn {
                items(apps) { app ->
                    val label = pm.getApplicationLabel(app).toString()
                    val isLocked = lockedPackages.contains(app.packageName)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(label, style = MaterialTheme.typography.bodyLarge)
                        Switch(
                            checked = isLocked,
                            onCheckedChange = { checked ->
                                LockedAppsRepository.toggle(context, app.packageName, checked)
                                lockedPackages = LockedAppsRepository.getLockedPackages(context)
                            }
                        )
                    }
                }
            }
        }
    }
}
