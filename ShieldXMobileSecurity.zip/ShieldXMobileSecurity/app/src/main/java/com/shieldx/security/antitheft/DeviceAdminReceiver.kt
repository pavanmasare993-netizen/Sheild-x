package com.shieldx.security.antitheft

import android.app.admin.DeviceAdminReceiver as AndroidDeviceAdminReceiver
import android.content.Context
import android.content.Intent
import android.widget.Toast

/**
 * Enables device-admin powers (force-lock, wipe-data) required for the
 * Anti-Theft module's remote Lock and Wipe actions. The user must
 * explicitly activate this under Settings > Security > Device admin apps
 * (the app should deep-link them there via
 * DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).
 */
class DeviceAdminReceiver : AndroidDeviceAdminReceiver() {

    override fun onEnabled(context: Context, intent: Intent) {
        Toast.makeText(context, "ShieldX device admin enabled", Toast.LENGTH_SHORT).show()
    }

    override fun onDisabled(context: Context, intent: Intent) {
        Toast.makeText(context, "ShieldX device admin disabled — Anti-Theft lock/wipe unavailable", Toast.LENGTH_LONG).show()
    }
}
