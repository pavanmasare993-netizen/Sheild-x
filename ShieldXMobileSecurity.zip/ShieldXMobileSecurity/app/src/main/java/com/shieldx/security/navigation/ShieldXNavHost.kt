package com.shieldx.security.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.shieldx.security.ui.alerts.AlertsScreen
import com.shieldx.security.ui.antitheft.AntiTheftScreen
import com.shieldx.security.ui.applock.AppLockScreen
import com.shieldx.security.ui.auth.LoginScreen
import com.shieldx.security.ui.auth.SignupScreen
import com.shieldx.security.ui.backup.CloudBackupScreen
import com.shieldx.security.ui.battery.BatteryHealthScreen
import com.shieldx.security.ui.dashboard.DashboardScreen
import com.shieldx.security.ui.devicesecurity.DeviceSecurityCheckScreen
import com.shieldx.security.ui.junkcleaner.JunkCleanerScreen
import com.shieldx.security.ui.permissionmanager.PermissionManagerScreen
import com.shieldx.security.ui.phishing.PhishingDetectionScreen
import com.shieldx.security.ui.privacyscanner.PrivacyScannerScreen
import com.shieldx.security.ui.ram.RamMonitorScreen
import com.shieldx.security.ui.safebrowsing.SafeBrowsingScreen
import com.shieldx.security.ui.settings.SettingsScreen
import com.shieldx.security.ui.storageanalyzer.StorageAnalyzerScreen
import com.shieldx.security.ui.vpn.VpnScreen
import com.shieldx.security.ui.wifisecurity.WifiSecurityScreen

@Composable
fun ShieldXNavHost(navController: NavHostController = rememberNavController()) {
    NavHost(navController = navController, startDestination = Routes.Login.route) {
        composable(Routes.Login.route) { LoginScreen(navController) }
        composable(Routes.Signup.route) { SignupScreen(navController) }
        composable(Routes.Dashboard.route) { DashboardScreen(navController) }
        composable(Routes.AppLock.route) { AppLockScreen(navController) }
        composable(Routes.PrivacyScanner.route) { PrivacyScannerScreen(navController) }
        composable(Routes.PermissionManager.route) { PermissionManagerScreen(navController) }
        composable(Routes.DeviceSecurityCheck.route) { DeviceSecurityCheckScreen(navController) }
        composable(Routes.WifiSecurityCheck.route) { WifiSecurityScreen(navController) }
        composable(Routes.SafeBrowsing.route) { SafeBrowsingScreen(navController) }
        composable(Routes.PhishingDetection.route) { PhishingDetectionScreen(navController) }
        composable(Routes.AntiTheft.route) { AntiTheftScreen(navController) }
        composable(Routes.JunkCleaner.route) { JunkCleanerScreen(navController) }
        composable(Routes.StorageAnalyzer.route) { StorageAnalyzerScreen(navController) }
        composable(Routes.BatteryHealth.route) { BatteryHealthScreen(navController) }
        composable(Routes.RamMonitor.route) { RamMonitorScreen(navController) }
        composable(Routes.Vpn.route) { VpnScreen(navController) }
        composable(Routes.Alerts.route) { AlertsScreen(navController) }
        composable(Routes.CloudBackup.route) { CloudBackupScreen(navController) }
        composable(Routes.Settings.route) { SettingsScreen(navController) }
    }
}
