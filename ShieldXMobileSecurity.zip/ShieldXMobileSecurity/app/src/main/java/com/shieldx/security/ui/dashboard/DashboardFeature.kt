package com.shieldx.security.ui.dashboard

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector
import com.shieldx.security.navigation.Routes

data class DashboardFeature(
    val title: String,
    val icon: ImageVector,
    val route: String
)

val dashboardFeatures = listOf(
    DashboardFeature("App Lock", Icons.Filled.Lock, Routes.AppLock.route),
    DashboardFeature("Privacy Scanner", Icons.Filled.Search, Routes.PrivacyScanner.route),
    DashboardFeature("Permission Manager", Icons.Filled.AdminPanelSettings, Routes.PermissionManager.route),
    DashboardFeature("Device Security Check", Icons.Filled.Shield, Routes.DeviceSecurityCheck.route),
    DashboardFeature("Wi-Fi Security Check", Icons.Filled.Wifi, Routes.WifiSecurityCheck.route),
    DashboardFeature("Safe Browsing", Icons.Filled.Public, Routes.SafeBrowsing.route),
    DashboardFeature("Phishing Detection", Icons.Filled.ReportProblem, Routes.PhishingDetection.route),
    DashboardFeature("Anti-Theft", Icons.Filled.GppMaybe, Routes.AntiTheft.route),
    DashboardFeature("Junk Cleaner", Icons.Filled.CleaningServices, Routes.JunkCleaner.route),
    DashboardFeature("Storage Analyzer", Icons.Filled.PieChart, Routes.StorageAnalyzer.route),
    DashboardFeature("Battery Health", Icons.Filled.BatteryChargingFull, Routes.BatteryHealth.route),
    DashboardFeature("RAM Monitor", Icons.Filled.Memory, Routes.RamMonitor.route),
    DashboardFeature("VPN", Icons.Filled.VpnLock, Routes.Vpn.route),
    DashboardFeature("Alerts", Icons.Filled.Notifications, Routes.Alerts.route),
    DashboardFeature("Cloud Backup", Icons.Filled.CloudUpload, Routes.CloudBackup.route),
    DashboardFeature("Settings", Icons.Filled.Settings, Routes.Settings.route)
)
