package com.shieldx.security.ui.auth

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

sealed class AuthUiState {
    object Idle : AuthUiState()
    object Loading : AuthUiState()
    object Success : AuthUiState()
    data class Error(val message: String) : AuthUiState()
}

class AuthViewModel : ViewModel() {
    private val auth = FirebaseAuth.getInstance()

    var uiState by mutableStateOf<AuthUiState>(AuthUiState.Idle)
        private set

    fun login(email: String, password: String) {
        if (email.isBlank() || password.isBlank()) {
            uiState = AuthUiState.Error("Email and password are required")
            return
        }
        uiState = AuthUiState.Loading
        viewModelScope.launch {
            try {
                auth.signInWithEmailAndPassword(email, password).await()
                uiState = AuthUiState.Success
            } catch (e: Exception) {
                uiState = AuthUiState.Error(e.message ?: "Login failed")
            }
        }
    }

    fun signup(email: String, password: String, confirmPassword: String) {
        if (password != confirmPassword) {
            uiState = AuthUiState.Error("Passwords do not match")
            return
        }
        if (password.length < 8) {
            uiState = AuthUiState.Error("Password must be at least 8 characters")
            return
        }
        uiState = AuthUiState.Loading
        viewModelScope.launch {
            try {
                auth.createUserWithEmailAndPassword(email, password).await()
                uiState = AuthUiState.Success
            } catch (e: Exception) {
                uiState = AuthUiState.Error(e.message ?: "Signup failed")
            }
        }
    }

    fun currentUserId(): String? = auth.currentUser?.uid

    fun resetState() {
        uiState = AuthUiState.Idle
    }
}
