package com.shieldx.security.ui.settings

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import com.shieldx.security.ui.common.PlaceholderScreen

/**
 * TODO: Toggle switches for each module, sign-out, and an "Update System"
 * section that checks app version against Firebase Remote Config.
 */
@Composable
fun SettingsScreen(navController: NavHostController) {
    PlaceholderScreen(
        title = "Settings",
        navController = navController,
        note = "Per-module toggles, notification preferences, sign-out, and app update checks (Firebase Remote Config)."
    )
}
