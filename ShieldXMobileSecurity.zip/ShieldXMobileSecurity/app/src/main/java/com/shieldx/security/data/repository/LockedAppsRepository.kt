package com.shieldx.security.data.repository

import android.content.Context

object LockedAppsRepository {
    private const val PREFS = "shieldx_app_lock"
    private const val KEY_LOCKED_APPS = "locked_packages"

    fun getLockedPackages(context: Context): Set<String> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return prefs.getStringSet(KEY_LOCKED_APPS, emptySet()) ?: emptySet()
    }

    fun setLockedPackages(context: Context, packages: Set<String>) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit().putStringSet(KEY_LOCKED_APPS, packages).apply()
    }

    fun toggle(context: Context, packageName: String, locked: Boolean) {
        val current = getLockedPackages(context).toMutableSet()
        if (locked) current.add(packageName) else current.remove(packageName)
        setLockedPackages(context, current)
    }
}
