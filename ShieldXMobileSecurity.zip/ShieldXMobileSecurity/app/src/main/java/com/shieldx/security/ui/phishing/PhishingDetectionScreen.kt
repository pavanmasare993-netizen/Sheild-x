package com.shieldx.security.ui.phishing

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import com.shieldx.security.ui.common.PlaceholderScreen

/**
 * TODO: Combine SMS/notification content scanning (with user consent and
 * RECEIVE_SMS or NotificationListenerService) with URL reputation checks
 * from SafeBrowsingScreen to flag likely phishing links in messages.
 */
@Composable
fun PhishingDetectionScreen(navController: NavHostController) {
    PlaceholderScreen(
        title = "Phishing Detection",
        navController = navController,
        note = "Flags suspicious links in SMS/notifications. Reuses the URL-reputation check built for Safe Browsing."
    )
}
